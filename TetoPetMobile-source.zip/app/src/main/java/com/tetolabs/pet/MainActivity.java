package com.tetolabs.pet;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 48, 32, 32);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackgroundColor(Color.rgb(255, 241, 247));

        TextView title = new TextView(this);
        title.setText("❤️ Teto Pet Mobile");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(150, 25, 75));
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView info = new TextView(this);
        info.setText("\nPrototipo inicial\n\nEsta version comprueba la mascota flotante, el movimiento y las reacciones al tocarla. El arte exacto del video, las animaciones completas y la voz se agregaran en una siguiente version.\n\nPulsa el boton y concede el permiso de mostrar sobre otras apps.");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        box.addView(info);

        Button start = new Button(this);
        start.setText("Activar mascota flotante");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, PetOverlayService.class));
                finish();
            }
        });
        box.addView(start);

        Button retry = new Button(this);
        retry.setText("Ya concedi el permiso");
        retry.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, PetOverlayService.class));
                finish();
            }
        });
        box.addView(retry);
        setContentView(box);
    }
}
