package com.tetolabs.pet;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.widget.Toast;

public class PetOverlayService extends Service {
    private WindowManager wm;
    private PetView pet;
    private WindowManager.LayoutParams params;
    private ToneGenerator tone;
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);
        pet = new PetView();
        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 40; params.y = 180;
        wm.addView(pet, params);
        Toast.makeText(this, "Teto Pet esta activa. Toca para cambiar su estado; arrastra para moverla.", Toast.LENGTH_LONG).show();
    }
    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        if (pet != null) try { wm.removeView(pet); } catch(Exception ignored) {}
        if (tone != null) tone.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }

    private class PetView extends View {
        Paint p = new Paint(3);
        float downX, downY; int startX, startY; long downTime;
        int mood = 0;
        float phase = 0;
        PetView() { super(PetOverlayService.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(180, 190); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            phase += 0.12f;
            float bob = (float)Math.sin(phase) * 4;
            c.save();
            c.translate(0, bob);
            // Temporary cute placeholder; replace with transparent Teto sprite frames in a later build.
            p.setColor(Color.argb(225, 255, 230, 241)); c.drawRoundRect(8, 8, 172, 180, 34, 34, p);
            p.setColor(Color.rgb(225, 45, 105));
            c.drawOval(20, 18, 62, 102, p); c.drawOval(118, 18, 160, 102, p);
            p.setColor(Color.rgb(245, 91, 139)); c.drawOval(36, 30, 144, 142, p);
            p.setColor(Color.rgb(255, 220, 233)); c.drawOval(48, 43, 132, 128, p);
            p.setColor(Color.rgb(65, 35, 55)); c.drawCircle(70, 78, 5, p); c.drawCircle(110, 78, 5, p);
            p.setColor(Color.rgb(230, 65, 115)); c.drawArc(78, 82, 102, 101, 10, 160, false, p);
            p.setColor(Color.rgb(190, 30, 82)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(17);
            String[] labels = {"TETO!", "¡Hola!", "Bailando", "Zzz..."};
            String label = labels[mood % labels.length];
            c.drawText(label, 90 - p.measureText(label)/2, 161, p);
            c.restore();
            postInvalidateDelayed(70);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; downTime=System.currentTimeMillis(); return true;
                case MotionEvent.ACTION_MOVE:
                    params.x = startX + (int)(e.getRawX()-downX);
                    params.y = startY + (int)(e.getRawY()-downY);
                    try { wm.updateViewLayout(this, params); } catch(Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    float dx=e.getRawX()-downX, dy=e.getRawY()-downY;
                    if (Math.abs(dx)<12 && Math.abs(dy)<12) {
                        mood=(mood+1)%4;
                        if(tone!=null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 100);
                        invalidate();
                    }
                    return true;
            }
            return true;
        }
    }
}
